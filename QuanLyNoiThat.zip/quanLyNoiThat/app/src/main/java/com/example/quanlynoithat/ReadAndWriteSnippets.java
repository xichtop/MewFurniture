package com.example.quanlynoithat;

import android.util.Log;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ReadAndWriteSnippets {
    private DatabaseReference mDatabase;

    public DatabaseReference getmDatabase() {
        return mDatabase;
    }

    public void setmDatabase(DatabaseReference mDatabase) {
        this.mDatabase = mDatabase;
    }

    public ReadAndWriteSnippets() {
        mDatabase = FirebaseDatabase.getInstance("https://quanlynoithat-df330-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference();
    }

    public void LoaiSanPham()    {
        mDatabase = FirebaseDatabase.getInstance("https://quanlynoithat-df330-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("loaisanpham");
    }

    public void SanPham()    {
        mDatabase = FirebaseDatabase.getInstance("https://quanlynoithat-df330-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("sanpham");
    }

    public void KhachHang()
    {
        mDatabase = FirebaseDatabase.getInstance("https://quanlynoithat-df330-default-rtdb.asia-southeast1.firebasedatabase.app/").getReference("khachhang");
    }
}
