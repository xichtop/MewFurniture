package com.example.quanlynoithat;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class thongTin_DoanhThu_Activity extends AppCompatActivity {
    EditText edtNam,edtThang;
    Button btnXacNhan,btnTroVe;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.frm_thong_tin_doanh_thu);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setControl();
        setEvent();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.them_actionbar,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId()){
            case R.id.AB_xacNhan:
            {
                Intent intent = new Intent(thongTin_DoanhThu_Activity.this, ketQua_doanhThu_Activity.class);
                Bundle bundle = new Bundle();
                bundle.putString("thang",edtThang.getText().toString());
                bundle.putString("nam",edtNam.getText().toString());
                intent.putExtras(bundle);
                startActivity(intent);
                return true;
            }
            case R.id.AB_troVe:
            {
                Intent intent = new Intent(thongTin_DoanhThu_Activity.this, MainActivity.class);
                startActivity(intent);
                return true;
            }
        }
        return super.onOptionsItemSelected(item);
    }
    private void setEvent() {
        btnXacNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(thongTin_DoanhThu_Activity.this, ketQua_doanhThu_Activity.class);
                Bundle bundle = new Bundle();
                bundle.putString("thang",edtThang.getText().toString());
                bundle.putString("nam",edtNam.getText().toString());
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        btnTroVe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(thongTin_DoanhThu_Activity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    private void setControl() {
        edtNam = findViewById(R.id.edtNam);
        edtThang = findViewById(R.id.edtThang);
        btnXacNhan = findViewById(R.id.btnThongKe);
        btnTroVe = findViewById(R.id.btnTroVe);
    }

}