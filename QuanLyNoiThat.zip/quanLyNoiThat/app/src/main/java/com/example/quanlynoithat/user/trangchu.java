package com.example.quanlynoithat.user;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toolbar;
import androidx.appcompat.widget.Toolbar;
import android.widget.ViewFlipper;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.quanlynoithat.R;
import com.google.android.material.navigation.NavigationView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class trangchu extends AppCompatActivity {
    Toolbar toolbar;
    ViewFlipper viewFlipper;
    RecyclerView recyclerView;
    NavigationView navigationView;
    ListView listView;
    DrawerLayout drawerLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.frm_san_pham);
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
        setControl();
        actionBar();
        actionviewFlipper();
    }

    private void actionviewFlipper() {
        ArrayList<String> mangAdvertising = new ArrayList<>();
        mangAdvertising.add("https://bit.ly/34o1rQz");
        mangAdvertising.add("https://bit.ly/34o1rQz");
        mangAdvertising.add("https://bit.ly/34o1rQz");
        mangAdvertising.add("https://bit.ly/34o1rQz");
        for (int i=0;i<mangAdvertising.size();i++)
        {
            ImageView imgView = new ImageView(getApplicationContext());
            Picasso.get().load(mangAdvertising.get(i)).into(imgView);
            imgView.setScaleType(ImageView.ScaleType.FIT_XY);
            viewFlipper.addView(imgView);
        }
        viewFlipper.setFlipInterval(5000);
        viewFlipper.setAutoStart(true);
        Animation animation_slide_in = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_in_right);
        Animation animation_slide_out = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.slide_out_left);
        viewFlipper.setInAnimation(animation_slide_in);
        viewFlipper.setOutAnimation(animation_slide_out);
    }


    private void setControl() {
        toolbar = findViewById(R.id.toolbarMain);
        viewFlipper = findViewById(R.id.viewFlipperMain);
        recyclerView = findViewById(R.id.recycleMain);
        navigationView = findViewById(R.id.NavigationMian);
        listView = findViewById(R.id.listviewMain);
        drawerLayout = findViewById(R.id.drawerLayoutMain);
    }

    private void actionBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            toolbar.setNavigationIcon(android.R.drawable.ic_menu_sort_by_size);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            toolbar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            });
        }
    }

}
